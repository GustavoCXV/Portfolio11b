package atividade__01;
public class Atividade__01 {
 public static void main(String[] args) {
    Caneta c1 = new Caneta();
    c1.cor = "Azul";
    c1.ponta = 0.5f;
    c1.modelo = "bic";
    c1.carga = 75;
    c1.tampada = false;
    c1.rabiscar();
    c1.status();
    
    Caneta c2 = new Caneta();
    c2.cor = "Preta";
    c2.ponta = 0.7f;
    c2.modelo = "lux";
    c2.carga = 80;
    c2.tampada = true;
    c2.rabiscar();
    c2.status();
    
    Caneta c3 = new Caneta();
    c3.cor = "Vermelha";
    c3.ponta = 0.5f;
    c3.modelo = "lux";
    c3.carga = 98;
    c3.tampada = false;
   c3.rabiscar();
   c3.status();
   
    Caneta c4 = new Caneta();
    c4.cor = "Verde";
    c4.modelo = "bic";
    c4.ponta = 0.7f;
    c4.carga = 98;
    c4.tampada = true;
    c4.rabiscar();
    c4.status();
    }
    
}
